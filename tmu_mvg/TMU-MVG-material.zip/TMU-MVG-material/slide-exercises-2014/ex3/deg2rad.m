function [ val ] = deg2rad( val )
val= val*pi/180;
end

