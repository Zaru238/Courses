function [dy] = dy_forward(u)

dy = 
