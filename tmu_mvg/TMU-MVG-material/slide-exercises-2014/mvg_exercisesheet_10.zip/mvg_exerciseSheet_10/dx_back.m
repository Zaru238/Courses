function [dx] = dx_back(u)

dx = 
