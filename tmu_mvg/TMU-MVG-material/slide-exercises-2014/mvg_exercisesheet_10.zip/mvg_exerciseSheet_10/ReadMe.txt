This folder includes the following files:


Some Example images:
bw.jpg
lena.jpg


Matlab-file including a rough structure of the final implementation:
codeFragment.m


Matlab-files to determine the forward- and backward-differences in x- and y-direction:
dx_forward.m (already done)
dy_forward.m
dx_back.m
dy_back.m