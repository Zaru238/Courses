function [dy] = dy_back(u)

dy = 